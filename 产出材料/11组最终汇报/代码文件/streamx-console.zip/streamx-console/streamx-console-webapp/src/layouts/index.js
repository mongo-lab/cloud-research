import EmptyView from './EmptyView'
import BasicView from './BasicView'
import RouteView from './RouteView'
import PageView from './PageView'

export { BasicView, EmptyView, RouteView, PageView }
